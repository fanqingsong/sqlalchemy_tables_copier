=====
Usage
=====

To use SQLAlchemy Tables Copier in a project::

    import sqlalchemy_tables_copier
