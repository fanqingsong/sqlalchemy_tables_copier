========================
SQLAlchemy Tables Copier
========================


.. image:: https://img.shields.io/pypi/v/sqlalchemy_tables_copier.svg
        :target: https://pypi.python.org/pypi/sqlalchemy_tables_copier

.. image:: https://img.shields.io/travis/fanqingsong/sqlalchemy_tables_copier.svg
        :target: https://travis-ci.com/fanqingsong/sqlalchemy_tables_copier

.. image:: https://readthedocs.org/projects/sqlalchemy-tables-copier/badge/?version=latest
        :target: https://sqlalchemy-tables-copier.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




Python Boilerplate contains all the boilerplate you need to create a Python package.


* Free software: MIT license
* Documentation: https://sqlalchemy-tables-copier.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage


=======
History
=======

0.1.0 (2023-02-25)
------------------

* First release on PyPI.


